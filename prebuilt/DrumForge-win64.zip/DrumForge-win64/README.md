# DrumForge

A fully synthesised **VST3 drum instrument**: 10 kit pieces, 220+ parameters, 40 factory presets, test pads for every sound, a loop-aware groove player with 28 factory patterns and an 8-slot **step-sequencer Groove Editor** (ratchets, probability, up to 64 steps), **Kit Morph** (mod wheel blends toward another preset), **Mutate**, per-drum transient shapers, sympathetic snare buzz, a room reverb, master EQ / saturator / bus compressor and a look-ahead limiter. No samples: the whole kit is a few MB of code, instant to load, and every piece can be reshaped.

* Windows x64 gets the full editor GUI (1120x700, DPI aware).
* Linux and macOS builds have the identical audio engine, parameters and presets; the host shows its generic parameter UI.
* 7 optional stereo stem outputs (Kick, Snare, Toms, Hats, Cymbals, Perc, Room) for mixing in your DAW.

See **docs/USER_GUIDE.md** for how to use it, with a worked example and the complete parameter reference.

## Build (Windows)

1. Install MSYS2 MinGW-w64 (`pacman -S mingw-w64-ucrt-x86_64-gcc`) **or** Visual Studio with the C++ workload.
2. `git clone --recurse-submodules https://github.com/steinbergmedia/vst3sdk.git third_party/vst3sdk`
3. Double-click / run `build_windows.bat` (add `install` as Administrator to copy it to `C:\Program Files\Common Files\VST3`).

Result: `build\win\DrumForge.vst3\Contents\x86_64-win\DrumForge.vst3` (this file is the DLL). Rescan plugins in your DAW.

## Build (any platform, CMake)

    cmake -S . -B build-x -DCMAKE_BUILD_TYPE=Release
    cmake --build build-x --target DrumForge

Output is in `build-x/raw/` and `build-x/bundle/`.

## Cross-compile the Windows DLL from Linux/macOS

    pip install ziglang
    cmake -S . -B build-win -G Ninja -DCMAKE_TOOLCHAIN_FILE=cmake/toolchain-zig-win64.cmake
    cmake --build build-win --target DrumForge

## Offline renderer

`cmake --build build-x --target df_render` builds a command-line tool that renders presets and grooves to WAV with no host needed (handy for auditioning and regression checks).

## Layout

    src/dsp       filters, resonators, noise, smoothing
    src/engine    parameters, voices, FX, grooves, presets, engine (no SDK dependency)
    src/plugin    VST3 processor / controller / factory, Win32 editor shell
    src/gui       software-rendered editor (platform independent)
    tools         renderer, analysis and fuzz scripts

Licences: see LICENSE-NOTICES.md.
